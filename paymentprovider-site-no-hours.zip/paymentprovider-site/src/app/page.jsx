import "./../styles/globals.css";
import PaymentProviderSite from "@/components/PaymentProviderSite";

export default function Page() {
  return <PaymentProviderSite />;
}
